package com.fis.bankingapplication.service;

import java.util.List;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.exceptions.NotEnoughBalance;
import com.fis.bankingapplication.model.Account;

public interface AccountService {
	
	//This is the account service interface class which is the service layer of the project.
	//It has the abstract methods 
	public abstract String createAccount(Account account);

	public abstract String updateAccount(Account account);

	public abstract String deleteAccount(long accNum) throws AccountNotFound;

	public abstract Account getAccount(long accNum) throws AccountNotFound;

 	public abstract List<Account> getAllAccounts();
 	
 	public abstract void depositIntoBalance(long accNum, double depositAmount) throws AccountNotFound;
	public abstract void withdrawFromBalance(long accNum,double withdrawAmount) throws NotEnoughBalance,AccountNotFound;
 	
	public abstract String FundTransfer(long fromAccount,long toAccount,double amount, String transType) throws NotEnoughBalance,AccountNotFound;

}
