package com.fis.bankingapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.exceptions.NotEnoughBalance;
import com.fis.bankingapplication.model.Account;

public interface AccountRepo extends JpaRepository<Account,Long>{

	//This is the interface class having  abstract methods.
	
	@Query("Update Account a set a.balance=a.balance+?2 where a.accNum=?1")
	@Modifying
 	public  void depositIntoBalance(@Param("accNum")long accNum,@Param("depositAmount") double depositAmount) throws AccountNotFound;
	
	@Query("Update Account a set a.balance=a.balance-?2 where a.accNum=?1")
	@Modifying
	public void withdrawFromBalance(long accNum,double withdrawAmount)throws NotEnoughBalance,AccountNotFound;
	
	
}
