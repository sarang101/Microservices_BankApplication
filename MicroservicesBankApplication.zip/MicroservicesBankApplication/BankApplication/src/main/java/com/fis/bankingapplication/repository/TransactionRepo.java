package com.fis.bankingapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.bankingapplication.model.Transaction;

public interface TransactionRepo extends JpaRepository<Transaction,Integer>{
	
	//This is the interface class having  abstract methods.
	//String addTransaction(Transaction transaction);
	//public List<Transaction> getAllTransactions();
	
	//DSL Grammer
	public List<Transaction> findByFromAccount(long fromAccount);
	
	
}


