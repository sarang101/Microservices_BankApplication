package com.fis.bankingapplication.service;

import java.util.List;
//import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.fis.bankingapplication.exceptions.AccountNotFound;
//import com.fis.bankingapplication.model.Account;
import com.fis.bankingapplication.model.Transaction;
import com.fis.bankingapplication.repository.TransactionRepo;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	//This is the transaction service implementation class which implements the abstract methods.
	@Autowired
	TransactionRepo repo;

	@Override
	public String addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		 repo.save(transaction);
		 return "Transaction Added Successfully";
	}

	@Override
	public List<Transaction> getTransactions(long fromAccount) {
		// TODO Auto-generated method stub
		return repo.findByFromAccount(fromAccount);
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}
