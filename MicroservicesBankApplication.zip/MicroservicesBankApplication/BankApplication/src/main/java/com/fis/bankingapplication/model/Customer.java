package com.fis.bankingapplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

//Registration
//This is the account entity class which has customers_info table fields & getter & setter functions.
//Also there are parameterized & default constructor
@Entity
@Table(name="customers_info")
public class Customer {
	
	@Id
	@Column(name="cid")
	 @GeneratedValue(generator = "sequence-generator")
    @GenericGenerator(
      name = "sequence-generator",
      strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
      parameters = {
        @Parameter(name = "sequence_name", value = "user_sequence"),
        @Parameter(name = "initial_value", value = "1"),
        @Parameter(name = "increment_size", value = "1")
        }
    )
	private int cusId;
	@Size(min = 6, max = 15, message = "Customer name length must be between 6-15")
	@NotBlank(message = "Customer name cannot be null or whitespace")
	private String cusName;
	@Email(message="Enter a valid Email address")
	private String cusEmail;
	@NotNull
	@NotBlank(message="Password is mandatory")
	private String cusPassword;
	private int cusMob;
    private long cusAadhar;
	@NotBlank(message = "Address cannot be null or whitespace")
	private String cusPrmAadd;
	private String cusResiAdd;
	@NotBlank(message = "DOB cannot be null or whitespace")
	private String cusDob;
	
	
	public Customer(int cusId, String cusName, String cusEmail, String cusPassword, int cusMob, long cusAadhar,
			String cusPrmAadd, String cusResiAdd, String cusDob) {
		super();
		this.cusId = cusId;
		this.cusName = cusName;
		this.cusEmail = cusEmail;
		this.cusPassword = cusPassword;
		this.cusMob = cusMob;
		this.cusAadhar = cusAadhar;
		this.cusPrmAadd = cusPrmAadd;
		this.cusResiAdd = cusResiAdd;
		this.cusDob = cusDob;
	}
	
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}


	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusEmail() {
		return cusEmail;
	}
	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}
	public String getCusPassword() {
		return cusPassword;
	}
	public void setCusPassword(String cusPassword) {
		this.cusPassword = cusPassword;
	}
	public int getCusMob() {
		return cusMob;
	}
	public void setCusMob(int cusMob) {
		this.cusMob = cusMob;
	}
	public long getCusAadhar() {
		return cusAadhar;
	}
	public void setCusAadhar(long cusAadhar) {
		this.cusAadhar = cusAadhar;
	}
	public String getCusPrmAadd() {
		return cusPrmAadd;
	}
	public void setCusPrmAadd(String cusPrmAadd) {
		this.cusPrmAadd = cusPrmAadd;
	}
	public String getCusResiAdd() {
		return cusResiAdd;
	}
	public void setCusResiAdd(String cusResiAdd) {
		this.cusResiAdd = cusResiAdd;
	}
	public String getCusDob() {
		return cusDob;
	}
	public void setCusDob(String cusDob) {
		this.cusDob = cusDob;
	}
	
	@Override
	public String toString() {
		return String.format(
				"Customer [cusId=%s, cusName=%s, cusEmail=%s, cusPassword=%s, cusMob=%s, cusAadhar=%s, cusPrmAadd=%s, cusResiAdd=%s, cusDob=%s]",
				cusId, cusName, cusEmail, cusPassword, cusMob, cusAadhar, cusPrmAadd, cusResiAdd, cusDob);
	}
	
	
	

}
