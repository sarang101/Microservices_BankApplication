package com.fis.bankingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapplication.model.Transaction;
import com.fis.bankingapplication.service.TransactionService;

//This is the object of type Transaction which we input.
    //{
	//"transId":1,
	//"transType":"Withdraw",
	//"fromAccount":"1",
	//"toAccount":"2",
	//"dateOfTransaction":"2001-03-15",
	//"amount":"2000",
	//"status":"Withdrawn",
	//}

//This is the transaction controller class having routes of the Restful APIs.
@RestController
@RequestMapping("/transactions")
public class TransactionController {
	
	@Autowired
	TransactionService service;
	
	@PostMapping("/addTransaction") // http://localhost:8080/transactions/addTransaction
	public String saveTransaction(@RequestBody @Validated Transaction transaction) {
		return service.addTransaction(transaction);
	}

	@GetMapping("/getTransactions/{tid}") // http://localhost:8080/transactions/getTransactions/888
	public List<Transaction> getTransactions(@PathVariable("tid") int fromAccount) {
		return service.getTransactions(fromAccount);
	}

	@GetMapping("/getAllTransactions") // http://localhost:8080/transactions/getAllTransactions
	public List<Transaction> getTransactions() {
		return service.getAllTransactions();
	}
	
}
