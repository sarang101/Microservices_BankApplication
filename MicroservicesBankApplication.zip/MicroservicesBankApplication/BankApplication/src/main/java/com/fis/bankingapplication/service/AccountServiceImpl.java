package com.fis.bankingapplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.exceptions.NotEnoughBalance;
import com.fis.bankingapplication.model.Account;
import com.fis.bankingapplication.model.Transaction;
import com.fis.bankingapplication.repository.AccountRepo;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	
	//This is the account service implementation class which implements the abstract methods.
	@Autowired
	AccountRepo repo;
	
	@Autowired
	TransactionService service;
	
	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		repo.save(account);
		return "Account Added Successfully!";
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		repo.save(account);
		return "Account Updated Successfully!";
	}

	@Override
	public String deleteAccount(long accNum) throws AccountNotFound{
		// TODO Auto-generated method stub
		Optional<Account> optional = repo.findById(accNum);
		if (optional.isPresent()) {
			repo.deleteById(accNum);
			return "Account Deleted Successfully";
		} else {
			throw new AccountNotFound("Account Id is invalid...");
		}
	}

	@Override
	public Account getAccount(long accNum) throws AccountNotFound{
		// TODO Auto-generated method stub
		Optional<Account> optional = repo.findById(accNum);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new AccountNotFound("Account Id is invalid...");
		}
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void depositIntoBalance(long accNum, double depositAmount) throws AccountNotFound{
		// TODO Auto-generated method stub
		Transaction trans=new Transaction();
		trans.setAmount(depositAmount);
		trans.setFromAccount(accNum);
		trans.setToAccount(0);
		trans.setTransType("Deposit");
		Optional<Account> optional = repo.findById(accNum);
		 if (optional.isPresent()) {
			 repo.depositIntoBalance(accNum, depositAmount);
			 trans.setStatus("Success");
			} else {
				trans.setStatus("Failed");
				throw new AccountNotFound("Account Id is invalid...");
			}
		 service.addTransaction(trans);
	}

	@Override 
	public void withdrawFromBalance(long accNum, double withdrawAmount)  throws NotEnoughBalance,AccountNotFound {
		// TODO Auto-generated method stub
		Transaction trans=new Transaction();
		trans.setAmount(withdrawAmount);
		trans.setFromAccount(accNum);
		trans.setToAccount(0);
		trans.setTransType("Withdraw");
		Optional<Account> optional = repo.findById(accNum);
		double currBalance=optional.get().getBalance();
		if(currBalance-withdrawAmount<0)
		{
			trans.setStatus("Failed");
			throw new NotEnoughBalance("Insufficient Balance");
		}
		else {
			repo.withdrawFromBalance(accNum, withdrawAmount);
			trans.setStatus("Success");
		}
		
		service.addTransaction(trans);
	}

	@Override
	public String FundTransfer(long fromAccount, long toAccount, double amount,String transType)
			throws NotEnoughBalance,AccountNotFound{
		// TODO Auto-generated method stub
		
		Optional<Account> optional = repo.findById(fromAccount);
		Optional<Account>optional1 = repo.findById(toAccount);
		String tranStatus=null;
		Transaction tran=new Transaction();
		tran.setAmount(amount);
		tran.setFromAccount(fromAccount);
		tran.setToAccount(toAccount);
		tran.setTransType(transType);
		
		if(optional.isPresent() & optional1.isPresent()) {
			Account acc=optional.get();
			double currBalance=acc.getBalance();
			if(currBalance<amount) {
				tranStatus="Failed";
				tran.setStatus(tranStatus);
				service.addTransaction(tran);
				throw new NotEnoughBalance("Balance is not sufficient");
				
			}else {
				tranStatus="Success";
				repo.withdrawFromBalance(fromAccount, amount);
				repo.depositIntoBalance(toAccount, amount);
				tran.setStatus(tranStatus);
				service.addTransaction(tran);
				return "Fund Transfer successful";
			}
		}else{
			tranStatus="Failed";
			tran.setStatus(tranStatus);
			service.addTransaction(tran);
			throw new AccountNotFound("Account number is wrong");
		}	
 
	}

}
