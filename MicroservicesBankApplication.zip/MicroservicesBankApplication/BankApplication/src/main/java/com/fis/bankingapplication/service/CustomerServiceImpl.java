package com.fis.bankingapplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapplication.exceptions.CustomerNotFound;
import com.fis.bankingapplication.model.Customer;
import com.fis.bankingapplication.repository.CustomerRepo;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	//This is the customer service implementation class which implements the abstract methods.
	@Autowired
	CustomerRepo repo;
	
	@Override
	public String addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repo.save(customer);
		return "Customer Added Successfully";
	}

	@Override
	public String updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repo.save(customer);
		return "Customer Updated Successfully";
	}

	@Override
	public Customer getCustomer(int cusId) throws CustomerNotFound{
		// TODO Auto-generated method stub
		Optional<Customer> optional = repo.findById(cusId);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new CustomerNotFound("Customer Id is invalid...");
		}
	}
	
	@Override
	public String deleteCustomer(int cusId) throws CustomerNotFound{
		// TODO Auto-generated method stub
		repo.deleteById(cusId);
		return "Customer Deleted Successfully";
	}
	
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	

}
