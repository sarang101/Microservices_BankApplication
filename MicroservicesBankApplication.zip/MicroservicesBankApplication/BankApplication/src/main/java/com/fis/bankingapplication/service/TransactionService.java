package com.fis.bankingapplication.service;

import java.util.List;

import com.fis.bankingapplication.model.Transaction;

public interface TransactionService {
	
	//This is the transaction service interface class which is the service layer of the project.
	//It has the abstract methods 
	String addTransaction(Transaction transaction);
	public List<Transaction> getTransactions(long fromAccount);
	public List<Transaction> getAllTransactions();
}
