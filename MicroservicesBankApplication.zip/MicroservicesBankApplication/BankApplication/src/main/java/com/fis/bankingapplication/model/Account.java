package com.fis.bankingapplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.Max;
//import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


//This is the account entity class which has accounts_info table fields & getter & setter functions.
//Also there are parameterized & default constructor
@Entity
@Table(name = "accounts_info")
public class Account {
	
	@Id
	@Column(name = "aid")
//	@Min(value = 100, message = "Account Number Cannot be less than 100")
//	@Max(value = 1000, message = "Account Number cannot be greater than 1000")
	 @GeneratedValue(generator = "sequence-generator")
    @GenericGenerator(
      name = "sequence-generator",
      strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
      parameters = {
        @Parameter(name = "sequence_name", value = "user_sequence"),
        @Parameter(name = "initial_value", value = "9900"),
        @Parameter(name = "increment_size", value = "1")
        }
    )
	private long accNum;
	private int customerId;
	@NotBlank(message = "Account Type cannot be null or whitespace")
	private String accountType;
	private String accountDate;
	@NotBlank(message = "Branch cannot be null or whitespace")
	private String branch;
	private Double balance;
	//@Size(min = 6, message = "ifsc length must be atleast of 6 digits")
	//@NotBlank(message = "ifsc cannot be null or whitespace")
	private int ifsc;
	
	
	public Account(int customerId, long accNum, String accountType, String accountDate, String branch, Double balance,
			int ifsc) {
		super();
		this.customerId = customerId;
		this.accNum = accNum;
		this.accountType = accountType;
		this.accountDate = accountDate;
		this.branch = branch;
		this.balance = balance;
		this.ifsc = ifsc;
	}
	
	
	public Account() {
		// TODO Auto-generated constructor stub
	}


	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountDate() {
		return accountDate;
	}
	public void setAccountDate(String accountDate) {
		this.accountDate = accountDate;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public int getIfsc() {
		return ifsc;
	}
	public void setIfsc(int ifsc) {
		this.ifsc = ifsc;
	}
	@Override
	public String toString() {
		return String.format(
				"Account [customerId=%s, accNum=%s, accountType=%s, accountDate=%s, branch=%s, balance=%s,ifsc=%s]",
				customerId, accNum, accountType, accountDate, branch, balance,ifsc);
	}
	
	
}
