package com.fis.bankingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.exceptions.NotEnoughBalance;
import com.fis.bankingapplication.model.Account;
import com.fis.bankingapplication.service.AccountService;

//This is the object of type Account which we input.
//{
//"accNum":110,
//"customerId":118,
//"accountType":"Savings",
//"accountDate":"2001-03-10",
//"branch":"Sultanpura",
//"balance":"10000",
//"ifsc":"123"
//}

//This is the account controller class having routes of the Restful APIs.
@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	AccountService service;
	
	@PostMapping("/createAccount") // http://localhost:8080/accounts/createAccount
	public String saveAccount(@RequestBody @Validated Account account) {
		return service.createAccount(account);
	}
	
	@PutMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
	public String updateAccount(@RequestBody @Validated Account account) {
		return service.updateAccount(account);
	}
	
	@DeleteMapping("/deleteAccount/{aid}") // http://localhost:8080/accounts/deleteAccount/888
	public String deleteAccount(@PathVariable("aid") @Validated long accNum) throws AccountNotFound{
		return service.deleteAccount(accNum);
		
	}
	
	
	@GetMapping("/getAccount/{aid}") // http://localhost:8080/accounts/getAccount/888
	public Account getAccount(@PathVariable("aid") @Validated long accNum) throws AccountNotFound{
				return service.getAccount(accNum);
			
	}
	
	
	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public List<Account> getAccounts() {
		return service.getAllAccounts();
	}
	
	@GetMapping("/depositIntoBalance/{accNum}/{depositAmount}") // http://localhost:8080/accounts/depositIntoBalance/888/888
	public void depositIntoBalance(@PathVariable("accNum")  long accNum,@PathVariable("depositAmount") double depositAmount)throws AccountNotFound {
		service.depositIntoBalance(accNum, depositAmount);
	}
	
	@GetMapping("/withdrawFromBalance/{accNum}/{withdrawAmount}") // http://localhost:8080/accounts/withdrawFromBalance/888/888
	public void withdrawFromBalance(@PathVariable("accNum")  long accNum,@PathVariable("withdrawAmount") double withdrawAmount) throws NotEnoughBalance,AccountNotFound{
			 service.withdrawFromBalance(accNum, withdrawAmount);
	}
	
	
	@GetMapping("/FundTransfer/{fromAccount}/{toAccount}/{amount}/{transType}") // http://localhost:8080/accounts/FundTransfer/1/2/1000/NEFT
	public String FundTransfer(@PathVariable("fromAccount") long fromAccount,@PathVariable("toAccount") long toAccount,@PathVariable("amount") double amount,@PathVariable("transType") String transType) throws NotEnoughBalance,AccountNotFound {
		 return service.FundTransfer(fromAccount,toAccount, amount,transType);
	}
}
